#!/usr/bin/env python3
"""Build a public, aggregate-only dashboard feed from two private workbooks.

Usage: python scripts/build_data.py 'Resultados - 2026.xlsx' 'Consulta Cliente - COMPLETO.xlsx'
Requires openpyxl. Input workbooks are never copied into site/.
"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import json
from pathlib import Path
import re
import unicodedata

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "site/data/summary.json"
RATES = {
    "Residencial": 8541, "Comercial": 44356, "Industrial": 61316,
    "Pública": 12915, "Pequeno comércio": 22178,
    "Social": 3012, "Comércio popular": 6024,
}
DOUBLE_CITIES = {"CORDEIRO", "MIRACEMA", "APERIBE"}
MONTHS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]


def norm(value):
    return unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().upper().strip()


def category(value):
    key = norm(value).replace(" ", "").replace(".", "")
    aliases = {
        "RESIDENCIAL": "Residencial", "RESIDENCIA": "Residencial",
        "COMERCIAL": "Comercial", "COMERCIO": "Comercial",
        "INDUSTRIAL": "Industrial", "PUBLICA": "Pública", "PUBLICO": "Pública",
        "PEQUENOCOMERCIO": "Pequeno comércio", "PCOMERCIO": "Pequeno comércio",
        "SOCIAL": "Social", "COMERCIOPOPULAR": "Comércio popular",
        "1COMERCIOPOPULAR": "Comércio popular",
    }
    return aliases.get(key)


TOKEN = re.compile(
    r"(\d+)\s*(?:ECONOMIAS?\s*(?:DE\s*)?)?"
    r"(PEQUENO\s+COMERCIO|P\.?\s*COMERCIO|COMERCIO\s+POPULAR|"
    r"RESIDENCIAIS|RESIDENCIAL|RESIDENCIAS|RESIDENCIA|RES\.?|RS\.?|"
    r"COMERCIAIS|COMERCIAL|COMERCIOS|COMERCIO|COM\.?|"
    r"INDUSTRIAL|PUBLICA|PUBLICO|SOCIAL)", re.I
)


def units(value):
    """Parse count/category pairs; reject other words that might hide a mixed change."""
    s = norm(value).replace("ECONOMIAS DE ", "").replace("ECONOMIA DE ", "")
    found = list(TOKEN.finditer(s))
    if not found:
        return None
    counts = Counter()
    for match in found:
        label = match.group(2)
        tail = s[match.end():match.end() + 14]
        if label.startswith(("RES", "RS")):
            kind = "Social" if re.match(r"\s*(?:S1\s*)?SOCIAL\b", tail) else "Residencial"
        elif label.startswith("PEQUENO") or label.startswith("P.") or re.match(r"P\s+COMERCIO", label):
            kind = "Pequeno comércio"
        elif "POPULAR" in label:
            kind = "Comércio popular"
        elif label.startswith("COM"):
            kind = "Comercial"
        elif label.startswith("IND"):
            kind = "Industrial"
        elif label.startswith("PUB"):
            kind = "Pública"
        else:
            kind = "Social"
        counts[kind] += int(match.group(1))
    return counts


def narrative(value):
    s = norm(value)
    # Only full before/after statements can determine a net tariff change.
    bits = re.split(r"\s+(?:P/|PARA)\s*", s, maxsplit=1)
    if len(bits) != 2 or not bits[0].startswith("DE "):
        return None
    before, after = units(bits[0][3:]), units(bits[1])
    if not before or not after:
        return None
    return before, after


def effect_vectors(before, after):
    """Match unchanged units, then conversions; remaining units are adds/removals."""
    old, new = Counter(before), Counter(after)
    effects = []
    for c in RATES:
        shared = min(old[c], new[c])
        old[c] -= shared
        new[c] -= shared
    old_left = [c for c in RATES for _ in range(old[c])]
    new_left = [c for c in RATES for _ in range(new[c])]
    for from_cat, to_cat in zip(old_left, new_left):
        effects.append(("categoria", from_cat, to_cat, 1))
    for c in old_left[len(new_left):]:
        effects.append(("economia", c, None, 1))
    for c in new_left[len(old_left):]:
        effects.append(("economia", None, c, 1))
    return effects


def parse_action(row):
    econ_flag, before_econ, after_econ = norm(row[9]), row[10], row[11]
    from_cat, to_cat, quantity = category(row[12]), category(row[13]), row[14]
    q_text = norm(quantity)
    story = narrative(quantity) if quantity is not None else None
    if story:
        before, after = story
    elif econ_flag and before_econ and after_econ:
        before, after = units(before_econ), units(after_econ)
        # A narrative repeated in both fields cannot be treated as two states.
        if norm(before_econ) == norm(after_econ) and " P/" in norm(before_econ):
            return None, "narrativa_ambigua"
        if not before or not after:
            return None, "sem_categoria_ou_quantidade"
    elif from_cat and to_cat and (not q_text or re.fullmatch(r"\d+", q_text)):
        quantity_num = int(q_text or "1")
        if quantity_num < 1:
            return None, "quantidade_invalida"
        before, after = Counter({from_cat: quantity_num}), Counter({to_cat: quantity_num})
    else:
        return None, "narrativa_ambigua"

    if max(sum(before.values()), sum(after.values())) > 50 or abs(sum(before.values()) - sum(after.values())) > 10:
        return None, "volume_atipico"
    effects = effect_vectors(before, after)
    if not effects:
        return None, "sem_variacao"
    return effects, None


def period_before(date):
    return f"{date.year - 1}-12" if date.month == 1 else f"{date.year}-{date.month - 1:02d}"


def load_events(path):
    sheet = load_workbook(path, read_only=True, data_only=True).active
    events = []
    last_date = None
    for row in sheet.iter_rows(min_row=2, values_only=True):
        date = row[2]
        if not isinstance(date, datetime) or norm(row[7]) != "CADASTRO":
            continue
        last_date = max(last_date or date, date)
        if row[9] or row[12] or row[13]:
            events.append(row)
    return events, last_date


def load_places(path, ids):
    sheet = load_workbook(path, read_only=True, data_only=True).worksheets[0]
    places = {}
    for row in sheet.iter_rows(min_row=2, values_only=True):
        key = str(row[2])
        if key in ids:
            city = norm(row[1])
            if key in places and places[key] != city:
                places[key] = None
            else:
                places[key] = city
    return places


def build(results, clients, closed_through=None):
    events, last_date = load_events(results)
    if not last_date:
        raise ValueError("Nenhuma data válida encontrada em Resultados.")
    closed_through = closed_through or period_before(last_date)
    places = load_places(clients, {str(row[6]) for row in events})
    aggregates = Counter()
    issues = Counter()
    seen = set()
    included = Counter()
    for row in events:
        month = row[2].strftime("%Y-%m")
        if month > closed_through:
            continue
        city = places.get(str(row[6]))
        issue_city = city or "Não conciliado"
        signature = (month, str(row[6]), *(norm(row[i]) for i in (9, 10, 11, 12, 13, 14)))
        if signature in seen:
            issues[(month, issue_city, "duplicada")] += 1
            continue
        seen.add(signature)
        if not city:
            issues[(month, issue_city, "sem_localidade")] += 1
            continue
        effects, reason = parse_action(row)
        if reason:
            issues[(month, city, reason)] += 1
            continue
        included[(month, city)] += 1
        factor = 2 if city in DOUBLE_CITIES else 1
        for kind, old, new, count in effects:
            aggregates[(month, city, kind, old or "", new or "", factor)] += count

    movements = [
        dict(month=m, city=city, kind=kind, previous=old or None, current=new or None, factor=factor, quantity=q)
        for (m, city, kind, old, new, factor), q in sorted(aggregates.items())
    ]
    quality = [dict(month=m, city=city, reason=reason, count=count)
               for (m, city, reason), count in sorted(issues.items())]
    months = sorted({m for m, _ in included} | {m for m, _, _ in issues})
    return {
        "source": {"results": "Resultados - 2026.xlsx", "clients": "Consulta Cliente - COMPLETO.xlsx",
                   "sourceMaxDate": last_date.date().isoformat(), "closedThrough": closed_through,
                   "billingRule": "Água e esgoto: Cordeiro, Miracema e Aperibé; demais locais: água."},
        "tariffsCents": RATES, "doubleCities": sorted(DOUBLE_CITIES),
        "months": months, "movements": movements,
        "quality": quality,
        "includedActions": [dict(month=m, city=city, count=count) for (m, city), count in sorted(included.items())],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("clients", type=Path)
    parser.add_argument("--closed-through", help="Último mês encerrado, formato AAAA-MM")
    args = parser.parse_args()
    data = build(args.results, args.clients, args.closed_through)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"{OUTPUT}: {len(data['movements'])} movimentos agregados; {sum(x['count'] for x in data['quality'])} pendências")
