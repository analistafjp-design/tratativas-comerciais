# Impacto do Cadastro

Painel estático e responsivo para mostrar o efeito das tratativas comerciais em economias, categorias e faturamento mensal estimado. Publicação em GitHub Pages a partir da pasta `site/`.

## Atualizar os dados

Os arquivos de clientes contêm dados pessoais e **não devem ser enviados a este repositório público**. Use as planilhas localmente:

```bash
python -m pip install openpyxl
python scripts/build_data.py "Resultados - 2026.xlsx" "Consulta Cliente - COMPLETO.xlsx"
```

O script grava somente dados **agregados por mês, localidade e tipo de mudança** em `site/data/summary.json`. Depois, publique a alteração no ramo `main`. O fluxo `.github/workflows/pages.yml` envia apenas `site/` ao Pages. Para prévia local: `python -m http.server 8000 -d site` e abra `http://localhost:8000`.

Por padrão, o último mês fechado é o anterior à data mais recente da planilha. É possível indicar outro período com `--closed-through 2026-09`. Meses em andamento ficam fora do painel.

## Regras

- O vínculo com a base de clientes usa `MATRICULA S/ DIGITO` → `N° da Ligação` para obter a localidade. Não são publicados nomes, matrículas, endereços ou identificadores de linha.
- Tarifas mensais por economia em `scripts/build_data.py` e no JSON gerado: residencial R$ 85,41; comercial R$ 443,56; industrial R$ 613,16; pública R$ 129,15; pequeno comércio R$ 221,78; social R$ 30,12; comércio popular R$ 60,24.
- Multiplicador 2× para Cordeiro, Miracema e Aperibé; 1× nas demais localidades. É uma **premissa baseada no município**, pois a base enviada não inclui um campo inequívoco para a cobrança conjunta de água e esgoto em cada ligação. Confirmar essa premissa com o faturamento antes de tratar a estimativa como valor efetivamente faturado.
- Diferença mensal = (economias após × tarifa após − economias antes × tarifa antes) × multiplicador. Mudanças combinadas de categoria e quantidade são decompostas para não contar a mesma economia duas vezes. Ganhos menos perdas formam o valor líquido.
- O mesmo movimento repetido para a mesma matrícula no mesmo mês é contado uma vez. Movimentos sem localidade, com narrativa inconclusiva, sem variação ou volume atípico ficam fora dos valores e aparecem como pendências agregadas. O limiar de volume atípico é diferença maior que 10 economias ou mais de 50 em um dos estados.
- A primeira fatura **cheia** de uma tratativa de julho é a de agosto. O impacto de uma safra até dezembro é seu valor líquido mensal × número de meses seguintes até dezembro. O equivalente em 12 meses pressupõe manutenção integral das alterações.

## Interpretação

Os valores são **potencial de faturamento recorrente**, não arrecadação comprovada nem conferência de faturas emitidas. O print fornecido está filtrado em **abril/2026**, enquanto o exemplo em texto atribui 136 incrementos, 38 trocas e R$ 9.551,07 a julho. A planilha atual não reproduz esse conjunto de números para julho. O painel calcula seus valores diretamente das duas planilhas, sem usar os números manuscritos do print como ajustes.

As tarifas podem ser simuladas pelo botão **Premissas de cálculo**; esse cenário fica apenas no navegador. Para alterar o valor oficial publicado, atualize `RATES`, gere novamente o JSON e publique ambos.
