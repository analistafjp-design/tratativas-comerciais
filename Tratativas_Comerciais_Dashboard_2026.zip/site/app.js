const $ = (selector) => document.querySelector(selector);
const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const compact = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact', maximumFractionDigits: 1 });
const monthLong = new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric', timeZone: 'UTC' });
const monthShort = new Intl.DateTimeFormat('pt-BR', { month: 'short', timeZone: 'UTC' });
let feed, baseRates, rates, selectedMonth, selectedCity = '';

function dateOf(month) { const [year, mm] = month.split('-').map(Number); return new Date(Date.UTC(year, mm - 1, 1)); }
function dateLabel(month) { return monthLong.format(dateOf(month)); }
function shortLabel(month) { return monthShort.format(dateOf(month)).replace('.', ''); }
function nextMonth(month) { const [y, m] = month.split('-').map(Number); return `${y + (m === 12 ? 1 : 0)}-${String(m === 12 ? 1 : m + 1).padStart(2, '0')}`; }
function brl(cents) { return money.format(cents / 100); }
function matching(item, month) { return item.month === month && (!selectedCity || item.city === selectedCity); }
function amount(item) { return item.quantity * item.factor * ((rates[item.current] || 0) - (rates[item.previous] || 0)); }

function totals(month) {
  const result = { net: 0, gains: 0, losses: 0, newEconomies: 0, lostEconomies: 0, upgrades: 0, downgrades: 0 };
  feed.movements.filter(item => matching(item, month)).forEach(item => {
    const value = amount(item);
    result.net += value;
    if (value > 0) result.gains += value;
    if (value < 0) result.losses -= value;
    if (item.kind === 'economia') {
      if (item.current) result.newEconomies += item.quantity;
      else result.lostEconomies += item.quantity;
    } else if (value > 0) result.upgrades += item.quantity;
    else if (value < 0) result.downgrades += item.quantity;
  });
  return result;
}

function chart() {
  const container = $('#monthly-chart');
  container.replaceChildren();
  const values = feed.months.map(m => totals(m).net);
  const max = Math.max(1, ...values.map(Math.abs));
  feed.months.forEach((month, i) => {
    const button = document.createElement('button');
    const value = values[i];
    button.type = 'button';
    button.className = `chart-item${value < 0 ? ' negative' : ''}${month === selectedMonth ? ' active' : ''}`;
    button.setAttribute('aria-label', `${dateLabel(month)}: ${brl(value)}. Selecionar mês`);
    button.setAttribute('aria-pressed', String(month === selectedMonth));
    const label = document.createElement('span'); label.className = 'chart-figure'; label.textContent = compact.format(value / 100);
    const plot = document.createElement('span'); plot.className = 'chart-plot';
    const bar = document.createElement('span'); bar.className = 'chart-fill'; bar.style.height = `${Math.max(3, Math.abs(value) / max * 162)}px`; plot.append(bar);
    const tick = document.createElement('span'); tick.className = 'chart-month'; tick.textContent = shortLabel(month).replace(/^./, ch => ch.toUpperCase());
    button.append(label, plot, tick);
    button.addEventListener('click', () => { selectedMonth = month; $('#period').value = month; render(); });
    container.append(button);
  });
}

function render() {
  const t = totals(selectedMonth);
  const monthAfter = nextMonth(selectedMonth);
  const year = Number(selectedMonth.slice(0, 4));
  const monthsRemaining = 12 - Number(selectedMonth.slice(5, 7));
  const issues = feed.quality.filter(item => matching(item, selectedMonth));
  const pending = issues.reduce((sum, item) => sum + item.count, 0);
  const duplicate = issues.filter(item => item.reason === 'duplicada').reduce((sum, item) => sum + item.count, 0);
  const actions = feed.includedActions.filter(item => matching(item, selectedMonth)).reduce((sum, item) => sum + item.count, 0);

  $('#period-description').textContent = `${dateLabel(selectedMonth)} · ${actions.toLocaleString('pt-BR')} tratativas conciliadas${selectedCity ? ` · ${selectedCity}` : ''}`;
  $('#new-economies').textContent = t.newEconomies.toLocaleString('pt-BR');
  $('#lost-economies').textContent = `${t.lostEconomies} economias retiradas consideradas nas perdas`;
  $('#category-upgrades').textContent = t.upgrades.toLocaleString('pt-BR');
  $('#category-downgrades').textContent = `${t.downgrades} trocas com redução de tarifa consideradas`;
  $('#monthly-label').textContent = `Fatura cheia de ${dateLabel(monthAfter)}`;
  $('#monthly-net').textContent = brl(t.net);
  $('#monthly-detail').textContent = 'Ganho líquido mensal estimado';
  $('#projection-label').textContent = `Até dezembro de ${year}`;
  $('#projection').textContent = brl(t.net * monthsRemaining);
  $('#annualized').textContent = `${brl(t.net * 12)} em 12 meses, se mantido`;
  $('#composition-period').textContent = `Tratativas de ${dateLabel(selectedMonth)}`;
  $('#net-repeat').textContent = brl(t.net);
  $('#gross-gain').textContent = brl(t.gains);
  $('#gross-loss').textContent = `− ${brl(t.losses)}`;
  const scale = Math.max(1, t.gains, t.losses);
  $('#gain-track').style.width = `${100 * t.gains / scale}%`;
  $('#loss-track').style.width = `${100 * t.losses / scale}%`;
  $('#data-note').textContent = pending
    ? `${pending} registro${pending === 1 ? '' : 's'} fora da estimativa por duplicidade, falta de conciliação ou informação ambígua${duplicate ? ` (${duplicate} duplicado${duplicate === 1 ? '' : 's'})` : ''}. Veja as regras em Premissas.`
    : 'Todas as tratativas estruturadas do período foram conciliadas.';
  $('#projection-description').textContent = `As ações de ${dateLabel(selectedMonth)} entram pela primeira vez na fatura cheia de ${dateLabel(monthAfter)}.`;
  $('#months-billed').textContent = `${monthsRemaining} ${monthsRemaining === 1 ? 'mês' : 'meses'} até dez/${year}`;
  const timeline = $('#projection-timeline'); timeline.replaceChildren();
  for (let i = 0, month = monthAfter; i < monthsRemaining; i++, month = nextMonth(month)) {
    const item = document.createElement('div'); item.className = `timeline-month${t.net < 0 ? ' negative' : ''}`;
    const name = document.createElement('span'); name.textContent = `${shortLabel(month)} / ${month.slice(0, 4)}`;
    const value = document.createElement('strong'); value.textContent = brl(t.net);
    item.append(name, value); timeline.append(item);
  }
  $('#scenario-flag').hidden = Object.keys(rates).every(key => rates[key] === baseRates[key]);
  chart();
}

function setupRates() {
  const fields = $('#tariff-fields'); fields.replaceChildren();
  Object.entries(baseRates).forEach(([name]) => {
    const label = document.createElement('label'); label.textContent = name;
    const field = document.createElement('input'); field.type = 'number'; field.step = '0.01'; field.min = '0'; field.required = true;
    field.dataset.category = name; field.value = (rates[name] / 100).toFixed(2);
    field.setAttribute('aria-label', `Tarifa mensal ${name} em reais`);
    label.append(field); fields.append(label);
  });
}

function setup() {
  const cities = [...new Set(feed.movements.map(x => x.city))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  $('#period').replaceChildren(...feed.months.map(month => new Option(dateLabel(month).replace(/^./, ch => ch.toUpperCase()), month)));
  $('#city').replaceChildren(new Option('Todas as localidades', ''), ...cities.map(city => new Option(city, city)));
  selectedMonth = feed.months.at(-1);
  $('#period').value = selectedMonth;
  $('#period').addEventListener('change', e => { selectedMonth = e.target.value; render(); });
  $('#city').addEventListener('change', e => { selectedCity = e.target.value; render(); });
  $('#status-text').textContent = `Fechado até ${dateLabel(feed.source.closedThrough)}`;
  $('#assumptions-button').addEventListener('click', () => { setupRates(); $('#assumptions-dialog').showModal(); });
  $('#apply-tariffs').addEventListener('click', () => {
    const inputs = [...$('#tariff-fields').querySelectorAll('input')];
    if (inputs.some(input => !input.reportValidity())) return;
    rates = Object.fromEntries(inputs.map(input => [input.dataset.category, Math.round(Number(input.value) * 100)]));
    try { localStorage.setItem('cadastro-rates', JSON.stringify(rates)); } catch (_) { /* temporary scenario still works */ }
    $('#assumptions-dialog').close(); render();
  });
  $('#reset-tariffs').addEventListener('click', () => {
    rates = { ...baseRates }; try { localStorage.removeItem('cadastro-rates'); } catch (_) { /* ignore */ }
    setupRates(); render();
  });
  render();
}

fetch('./data/summary.json', { cache: 'no-cache' })
  .then(response => { if (!response.ok) throw new Error(`HTTP ${response.status}`); return response.json(); })
  .then(data => {
    feed = data; baseRates = { ...data.tariffsCents }; rates = { ...baseRates };
    try {
      const saved = JSON.parse(localStorage.getItem('cadastro-rates'));
      if (saved && Object.keys(baseRates).every(key => Number.isInteger(saved[key]) && saved[key] >= 0)) rates = saved;
    } catch (_) { /* default rates */ }
    if (!feed.months.length) throw new Error('Não há meses fechados na base.');
    setup();
  })
  .catch(error => {
    $('#status-text').textContent = 'Falha ao carregar';
    const message = document.createElement('p'); message.className = 'error'; message.textContent = `Não foi possível carregar os dados do painel: ${error.message}`;
    $('#main').prepend(message);
  });
