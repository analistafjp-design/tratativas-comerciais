import sys
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from build_data import effect_vectors, narrative, parse_action, units


class BillingRulesTest(unittest.TestCase):
    def test_combined_addition_does_not_create_category_upgrade(self):
        old, new = narrative("DE 1 RES. P/ 1 RES. E 1 COM.")
        self.assertEqual(effect_vectors(old, new), [("economia", None, "Comercial", 1)])

    def test_social_to_two_residential_has_one_conversion_and_one_addition(self):
        old, new = narrative("DE 1 RES. SOCIAL P/ 2 RES. NORMAIS")
        self.assertEqual(effect_vectors(old, new), [
            ("categoria", "Social", "Residencial", 1),
            ("economia", None, "Residencial", 1),
        ])

    def test_outlier_is_held_for_review(self):
        row = [None] * 18
        row[9:12] = ["Decremento", "100 RES.", "1 Residência"]
        effects, issue = parse_action(row)
        self.assertIsNone(effects)
        self.assertEqual(issue, "volume_atipico")

    def test_simple_category_difference(self):
        row = [None] * 18
        row[12:15] = ["Social", "Residencial", "1"]
        effects, issue = parse_action(row)
        self.assertIsNone(issue)
        self.assertEqual(effects, [("categoria", "Social", "Residencial", 1)])


if __name__ == "__main__":
    unittest.main()
